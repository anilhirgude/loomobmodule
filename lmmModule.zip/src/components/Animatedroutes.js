import React from 'react'
import {Route, Routes, useLocation} from "react-router-dom";
import Home from './Home';
import Preview1 from './Preview1';
import Preview2 from './Preview2';
import Preview3 from './Preview3';
import {AnimatePresence} from "framer-motion";

const Animatedroutes = () => {
    const location = useLocation();
  return (
        <AnimatePresence exitBeforeEnter>
        <Routes location={location} key={location.pathname}>
        <Route exact path="/" element={<Home />}/>
          
          <Route path="/Preview1" element={<Preview1 />} />
          <Route path="/Preview2" element={< Preview2/>} />
          <Route path="/Preview3" element={< Preview3/>} />
        </Routes>
        </AnimatePresence>
      
    
  )
}

export default Animatedroutes

