import React from "react";
import Header from "./Header";
import Item from "./Item";
import image1 from "../assets/1.jpg";
import image2 from "../assets/2.jpg";
import image3 from "../assets/3.jpg";
import { motion } from "framer-motion";
import "./Home.css";

const Home = () => {
  return (
    <motion.div>
      
      <motion.div
          exit={{ opacity: 1, height: "50vh" }}
          transition={{ duration: 2 }}
          className="top__row"
        ></motion.div>
        <motion.div
          exit={{ opacity: 1, height: "50vh" }}
          transition={{ duration: 2 }}
          className="bottom__row"
        ></motion.div>
      <Header />
      <div className="content">
        <Item
          img={image1}
          item__meta="2020"
          item__title="Alex"
          item__desc="lorem ipsum"
          item__link="/Preview1"
        />
        <Item
          img={image2}
          item__meta="2021"
          item__title="Jemmy"
          item__desc="lorem ipsum"
          item__link="/Preview2"
        />
        <Item
          img={image3}
          item__meta="2022"
          item__title="Aria"
          item__desc="lorem ipsum"
          item__link="/Preview3"
        />
      </div>
    </motion.div>
  );
};

export default Home;
