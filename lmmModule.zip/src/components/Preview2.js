import React from 'react'
import Header from './Header'
import {motion} from 'framer-motion'
import img from '../assets/2_big.jpg'

const Preview2 = () => {
    const text = {
		hidden: { y: -80, opacity: 0 },
		visible: {
		  y: 0,
		  opacity: 1,
		  transition: {
			duration:2
		  }
		}
	 }

	  const item = {
		hidden: { y: 100, opacity: 0 },
		visible: {
		  y: 0,
		  opacity: 1,
		  transition: {
			duration:2
		  }
		}
	  };

  return (
    <motion.div className="previews">
		
		 <Header/>
		
				<div className="preview">
					
				<div className="preview__img"><img className="preview__img-inner"  src={img} alt=""/></div>
					<motion.h2 className="preview__title oh"  variants={item}
    initial="hidden"
    animate="visible"><span className="oh__inner">Moulder</span></motion.h2>
					<motion.div className="preview__column preview__column--start" variants={text} initial="hidden"
    animate="visible">
						<span className="preview__column-title preview__column-title--main oh"><span className="oh__inner">Alex Moulder</span></span>
						<span className="oh"><span className="oh__inner">2020</span></span>
					</motion.div>
					<motion.div className="preview__column" variants={text} initial="hidden"
    animate="visible">
						<h3 className="preview__column-title oh"><span className="oh__inner">Location</span></h3>
						<p>And if it rains, a closed car at four. And we shall play a game of chess, pressing lidless eyes and waiting for a knock upon the door.</p>
					</motion.div>
					<motion.div className="preview__column" variants={text} initial="hidden"
    animate="visible">
						<h3 className="preview__column-title oh"><span className="oh__inner">Material</span></h3>
						<p>At the violet hour, when the eyes and back, turn upward from the desk, when the human engine waits.</p>
					</motion.div>
					<button className="unbutton preview__back"><svg width="100px" height="18px" viewBox="0 0 50 9"><path vector-effect="non-scaling-stroke" d="m0 4.5 5-3m-5 3 5 3m45-3h-77"></path></svg></button>
				</div>
                </motion.div>
  )
}

export default Preview2