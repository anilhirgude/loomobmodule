import React from 'react'
import "../App.css";

import {motion} from "framer-motion"
import {Link} from "react-router-dom"
//import "../components/Item.css"

const transition = {duration:0.6, ease: [0.43, 0.13, 0.23, 0.96]}
const Item =(props) => {
    
	

  return (
    
        
				<div className="item">
					<span className="item__meta">{props.item__meta}</span>
					<h2 className="item__title">{props.item__title}</h2>
					<div 
					
					className="item__img">
						<img className="item__img-inner" src={props.img} alt=""/>
						 {(src)=>(
							<motion.img
							src={src}
							whileHover={{scale: 1.1}}
							transition={transition}
							/>
						 )}
					     
						</div>
					<p className="item__desc">{props.item__desc}</p>
					<div>
					<Link className="item__link" to={props.item__link}>
                         view
						</Link>
					</div>
				</div>
    
  )
}

export default Item