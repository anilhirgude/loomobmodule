import React from "react";
import Header from "./Header";
import img from "../assets/1_big.jpg";
import { motion } from "framer-motion";
import "./Preview.css";

import { Link } from "react-router-dom";

const Preview1 = () => {
  const texts = {
    hidden: { y: -80, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 2,
      },
    },
  };

  const item = {
    hidden: { y: 100, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 2,
      },
    },
  };

  const imageAnimation = {
    hidden: { y: -100, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 2,
      },
    },
  };

  return (
    <motion.div className="previews">
      <Header />

      <div className="preview">
        <motion.div className="preview__img" style={{ position: "relative" }}>
          <motion.img className="preview__img-inner" src={img} alt="" />
          <motion.div
            initial={{ height: "100%" }}
            animate={{ height: "0%" }}
            transition={{ duration: 0.7 }}
            style={{
              position: "absolute",
              bottom: 0,
              left: 0,
              width: "100%",
              backgroundColor: "black",
            }}
            className="overlay_black"
          ></motion.div>
        </motion.div>
        <motion.h2
          className="preview__title oh"
          variants={item}
          initial="hidden"
          animate="visible"
        >
          <span className="oh__inner">Moulder</span>
        </motion.h2>

        <motion.div
          className="preview__column preview__column--start"
          variants={texts}
          initial="hidden"
          animate="visible"
        >
          <span className="preview__column-title preview__column-title--main oh">
            <span className="oh__inner">Alex Moulder</span>
          </span>
          <span className="oh">
            <span className="oh__inner">2020</span>
          </span>
        </motion.div>
        <motion.div
          className="preview__column"
          variants={texts}
          initial="hidden"
          animate="visible"
        >
          <h3 className="preview__column-title oh">
            <span className="oh__inner">Location</span>
          </h3>
          <p>
            And if it rains, a closed car at four. And we shall play a game of
            chess, pressing lidless eyes and waiting for a knock upon the door.
          </p>
        </motion.div>
        <motion.div
          className="preview__column"
          variants={texts}
          initial="hidden"
          animate="visible"
        >
          <h3 className="preview__column-title oh">
            <span className="oh__inner">Material</span>
          </h3>
          <p>
            At the violet hour, when the eyes and back, turn upward from the
            desk, when the human engine waits.
          </p>
        </motion.div>
        <Link to="/" className="unbutton preview__back">
          <svg width="100px" height="18px" viewBox="0 0 50 9">
            <path
              vector-effect="non-scaling-stroke"
              d="m0 4.5 5-3m-5 3 5 3m45-3h-77"
            ></path>
          </svg>
        </Link>
      </div>
    </motion.div>
  );
};

export default Preview1;
