
import './App.css';
import {BrowserRouter} from "react-router-dom";
import Animatedroutes from './components/Animatedroutes';


function App() {
  return (<div>
   <BrowserRouter>
      <Animatedroutes/>
    </BrowserRouter>
   
   
  </div>
   
  );
}

export default App;
